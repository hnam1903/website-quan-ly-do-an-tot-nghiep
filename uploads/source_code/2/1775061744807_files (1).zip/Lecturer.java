package com.thesis.management.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "lecturers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Lecturer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "lecturer_id")
    private Long lecturerId;
    
    @OneToOne
    @JoinColumn(name = "user_id", unique = true, nullable = false)
    private User user;
    
    @ManyToOne
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
    
    @Column(length = 50)
    private String position; // Chức vụ: Trưởng bộ môn, Phó trưởng bộ môn, Giảng viên
    
    @Column(length = 50)
    private String degree; // Học vị: Tiến sĩ, Thạc sĩ, Cử nhân
    
    @Column(columnDefinition = "TEXT")
    private String bio; // Giới thiệu
    
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "lecturer", cascade = CascadeType.ALL)
    private List<Thesis> theses;
    
    @OneToMany(mappedBy = "lecturer", cascade = CascadeType.ALL)
    private List<Comment> comments;
}
