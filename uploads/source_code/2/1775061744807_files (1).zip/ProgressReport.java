package com.thesis.management.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "progress_reports", 
       uniqueConstraints = @UniqueConstraint(columnNames = {"thesis_id", "report_period"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProgressReport {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "report_id")
    private Long reportId;
    
    @ManyToOne
    @JoinColumn(name = "thesis_id", nullable = false)
    private Thesis thesis;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "report_period", nullable = false)
    private ReportPeriod reportPeriod;
    
    @Column(name = "completed_tasks", nullable = false, columnDefinition = "TEXT")
    private String completedTasks; // Chức năng đã hoàn thành
    
    @Column(columnDefinition = "TEXT")
    private String difficulties; // Khó khăn gặp phải
    
    @Column(name = "file_url")
    private String fileUrl; // Link file báo cáo
    
    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;
    
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "progressReport", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments;
    
    public enum ReportPeriod {
        EARLY_TERM,  // Đầu kỳ
        MID_TERM,    // Giữa kỳ
        FINAL_TERM   // Cuối kỳ
    }
}
