package com.thesis.management.controller;

import com.thesis.management.dto.request.CommentRequest;
import com.thesis.management.dto.request.ProgressReportRequest;
import com.thesis.management.dto.response.CommentResponse;
import com.thesis.management.dto.response.ProgressReportResponse;
import com.thesis.management.security.CurrentUser;
import com.thesis.management.security.UserPrincipal;
import com.thesis.management.service.ProgressReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/progress-reports")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ProgressReportController {
    
    private final ProgressReportService progressReportService;
    
    /**
     * Sinh viên nộp báo cáo tiến độ
     * POST /api/progress-reports
     */
    @PostMapping
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<ProgressReportResponse> submitReport(
            @CurrentUser UserPrincipal currentUser,
            @Valid @RequestBody ProgressReportRequest request) {
        ProgressReportResponse response = progressReportService.submitReport(currentUser.getUserId(), request);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Giảng viên nhận xét báo cáo
     * POST /api/progress-reports/{reportId}/comments
     */
    @PostMapping("/{reportId}/comments")
    @PreAuthorize("hasRole('LECTURER')")
    public ResponseEntity<CommentResponse> addComment(
            @PathVariable Long reportId,
            @CurrentUser UserPrincipal currentUser,
            @Valid @RequestBody CommentRequest request) {
        CommentResponse response = progressReportService.addComment(reportId, currentUser.getLecturerId(), request);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Sinh viên xem báo cáo tiến độ của mình
     * GET /api/progress-reports/my-reports
     */
    @GetMapping("/my-reports")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<List<ProgressReportResponse>> getMyReports(@CurrentUser UserPrincipal currentUser) {
        // Get thesis ID from current user's student ID
        Long thesisId = currentUser.getStudentId(); // This needs to be fixed in actual implementation
        List<ProgressReportResponse> responses = progressReportService.getReportsByThesisId(thesisId);
        return ResponseEntity.ok(responses);
    }
    
    /**
     * Giảng viên xem tất cả báo cáo của sinh viên mình hướng dẫn
     * GET /api/progress-reports/supervised
     */
    @GetMapping("/supervised")
    @PreAuthorize("hasRole('LECTURER')")
    public ResponseEntity<List<ProgressReportResponse>> getSupervisedReports(@CurrentUser UserPrincipal currentUser) {
        List<ProgressReportResponse> responses = progressReportService.getReportsByLecturerId(currentUser.getLecturerId());
        return ResponseEntity.ok(responses);
    }
    
    /**
     * Xem chi tiết báo cáo
     * GET /api/progress-reports/{reportId}
     */
    @GetMapping("/{reportId}")
    @PreAuthorize("hasAnyRole('STUDENT', 'LECTURER', 'ADMIN')")
    public ResponseEntity<ProgressReportResponse> getReportById(@PathVariable Long reportId) {
        ProgressReportResponse response = progressReportService.getReportById(reportId);
        return ResponseEntity.ok(response);
    }
}
