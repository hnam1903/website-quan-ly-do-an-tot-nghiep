package com.thesis.management.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "student_id")
    private Long studentId;
    
    @OneToOne
    @JoinColumn(name = "user_id", unique = true, nullable = false)
    private User user;
    
    @Column(name = "student_code", unique = true, nullable = false, length = 20)
    private String studentCode;
    
    @ManyToOne
    @JoinColumn(name = "major_id", nullable = false)
    private Major major;
    
    @Column(name = "class_name", length = 50)
    private String className;
    
    @Column(name = "date_of_birth")
    private LocalDate dateOfBirth;
    
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
    private Thesis thesis;
}
