package com.thesis.management.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "theses")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Thesis {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "thesis_id")
    private Long thesisId;
    
    @OneToOne
    @JoinColumn(name = "student_id", unique = true, nullable = false)
    private Student student;
    
    @ManyToOne
    @JoinColumn(name = "lecturer_id", nullable = false)
    private Lecturer lecturer;
    
    @Column(name = "thesis_title", nullable = false)
    private String thesisTitle;
    
    @Column(name = "thesis_content", nullable = false, columnDefinition = "TEXT")
    private String thesisContent;
    
    @Column(name = "technology_used")
    private String technologyUsed;
    
    @Column(length = 20)
    private String semester; // VD: HK1 2024-2025
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ThesisStatus status = ThesisStatus.PENDING;
    
    @Column(precision = 4, scale = 2)
    private BigDecimal score; // Điểm từ 0-10
    
    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;
    
    @Column(name = "approved_at")
    private LocalDateTime approvedAt;
    
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "thesis", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProgressReport> progressReports;
    
    public enum ThesisStatus {
        PENDING,   // Chờ duyệt
        APPROVED,  // Đã duyệt
        REJECTED   // Từ chối
    }
}
