package com.thesis.management.controller;

import com.thesis.management.dto.request.ThesisRequest;
import com.thesis.management.dto.response.ThesisResponse;
import com.thesis.management.security.CurrentUser;
import com.thesis.management.security.UserPrincipal;
import com.thesis.management.service.ThesisService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/theses")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ThesisController {
    
    private final ThesisService thesisService;
    
    /**
     * Sinh viên đăng ký đề tài
     * POST /api/theses/register
     */
    @PostMapping("/register")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<ThesisResponse> registerThesis(
            @CurrentUser UserPrincipal currentUser,
            @Valid @RequestBody ThesisRequest request) {
        ThesisResponse response = thesisService.registerThesis(currentUser.getUserId(), request);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Giảng viên duyệt đề tài
     * PUT /api/theses/{thesisId}/approve
     */
    @PutMapping("/{thesisId}/approve")
    @PreAuthorize("hasRole('LECTURER')")
    public ResponseEntity<ThesisResponse> approveThesis(
            @PathVariable Long thesisId,
            @CurrentUser UserPrincipal currentUser) {
        ThesisResponse response = thesisService.approveThesis(thesisId, currentUser.getLecturerId());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Giảng viên từ chối đề tài
     * PUT /api/theses/{thesisId}/reject
     */
    @PutMapping("/{thesisId}/reject")
    @PreAuthorize("hasRole('LECTURER')")
    public ResponseEntity<ThesisResponse> rejectThesis(
            @PathVariable Long thesisId,
            @CurrentUser UserPrincipal currentUser) {
        ThesisResponse response = thesisService.rejectThesis(thesisId, currentUser.getLecturerId());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Giảng viên chấm điểm
     * PUT /api/theses/{thesisId}/grade
     */
    @PutMapping("/{thesisId}/grade")
    @PreAuthorize("hasRole('LECTURER')")
    public ResponseEntity<ThesisResponse> gradeThesis(
            @PathVariable Long thesisId,
            @RequestParam BigDecimal score,
            @CurrentUser UserPrincipal currentUser) {
        ThesisResponse response = thesisService.gradeThesis(thesisId, currentUser.getLecturerId(), score);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Sinh viên xem đề tài của mình
     * GET /api/theses/my-thesis
     */
    @GetMapping("/my-thesis")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<ThesisResponse> getMyThesis(@CurrentUser UserPrincipal currentUser) {
        ThesisResponse response = thesisService.getThesisByStudentId(currentUser.getStudentId());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Giảng viên xem danh sách đề tài mình hướng dẫn
     * GET /api/theses/my-supervised
     */
    @GetMapping("/my-supervised")
    @PreAuthorize("hasRole('LECTURER')")
    public ResponseEntity<List<ThesisResponse>> getMySupervisedTheses(@CurrentUser UserPrincipal currentUser) {
        List<ThesisResponse> responses = thesisService.getThesesByLecturerId(currentUser.getLecturerId());
        return ResponseEntity.ok(responses);
    }
    
    /**
     * Admin xem tất cả đề tài
     * GET /api/theses
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ThesisResponse>> getAllTheses() {
        List<ThesisResponse> responses = thesisService.getAllTheses();
        return ResponseEntity.ok(responses);
    }
    
    /**
     * Xóa đề tài
     * DELETE /api/theses/{thesisId}
     */
    @DeleteMapping("/{thesisId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'LECTURER')")
    public ResponseEntity<Void> deleteThesis(@PathVariable Long thesisId) {
        thesisService.deleteThesis(thesisId);
        return ResponseEntity.noContent().build();
    }
}
