package com.thesis.management.service;

import com.thesis.management.dto.request.ThesisRequest;
import com.thesis.management.dto.response.ThesisResponse;
import com.thesis.management.entity.*;
import com.thesis.management.exception.ResourceNotFoundException;
import com.thesis.management.repository.LecturerRepository;
import com.thesis.management.repository.StudentRepository;
import com.thesis.management.repository.ThesisRepository;
import com.thesis.management.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ThesisService {
    
    private final ThesisRepository thesisRepository;
    private final StudentRepository studentRepository;
    private final LecturerRepository lecturerRepository;
    private final UserRepository userRepository;
    
    @Transactional
    public ThesisResponse registerThesis(Long userId, ThesisRequest request) {
        // Get student by user ID
        Student student = studentRepository.findByUser_UserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy thông tin sinh viên"));
        
        // Check if student already has a thesis
        if (thesisRepository.existsByStudent_StudentId(student.getStudentId())) {
            throw new RuntimeException("Sinh viên đã đăng ký đề tài");
        }
        
        // Get lecturer
        Lecturer lecturer = lecturerRepository.findById(request.getLecturerId())
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy giảng viên"));
        
        // Create thesis
        Thesis thesis = Thesis.builder()
                .student(student)
                .lecturer(lecturer)
                .thesisTitle(request.getThesisTitle())
                .thesisContent(request.getThesisContent())
                .technologyUsed(request.getTechnologyUsed())
                .semester(request.getSemester())
                .status(Thesis.ThesisStatus.PENDING)
                .submittedAt(LocalDateTime.now())
                .build();
        
        thesis = thesisRepository.save(thesis);
        
        return mapToResponse(thesis);
    }
    
    @Transactional
    public ThesisResponse approveThesis(Long thesisId, Long lecturerId) {
        Thesis thesis = thesisRepository.findById(thesisId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đề tài"));
        
        // Check if lecturer is the supervisor
        if (!thesis.getLecturer().getLecturerId().equals(lecturerId)) {
            throw new RuntimeException("Bạn không có quyền duyệt đề tài này");
        }
        
        thesis.setStatus(Thesis.ThesisStatus.APPROVED);
        thesis.setApprovedAt(LocalDateTime.now());
        
        thesis = thesisRepository.save(thesis);
        
        return mapToResponse(thesis);
    }
    
    @Transactional
    public ThesisResponse rejectThesis(Long thesisId, Long lecturerId) {
        Thesis thesis = thesisRepository.findById(thesisId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đề tài"));
        
        // Check if lecturer is the supervisor
        if (!thesis.getLecturer().getLecturerId().equals(lecturerId)) {
            throw new RuntimeException("Bạn không có quyền từ chối đề tài này");
        }
        
        thesis.setStatus(Thesis.ThesisStatus.REJECTED);
        
        thesis = thesisRepository.save(thesis);
        
        return mapToResponse(thesis);
    }
    
    @Transactional
    public ThesisResponse gradeThesis(Long thesisId, Long lecturerId, BigDecimal score) {
        Thesis thesis = thesisRepository.findById(thesisId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đề tài"));
        
        // Check if lecturer is the supervisor
        if (!thesis.getLecturer().getLecturerId().equals(lecturerId)) {
            throw new RuntimeException("Bạn không có quyền chấm điểm đề tài này");
        }
        
        // Validate score (0-10)
        if (score.compareTo(BigDecimal.ZERO) < 0 || score.compareTo(BigDecimal.TEN) > 0) {
            throw new RuntimeException("Điểm phải từ 0 đến 10");
        }
        
        thesis.setScore(score);
        
        thesis = thesisRepository.save(thesis);
        
        return mapToResponse(thesis);
    }
    
    public ThesisResponse getThesisByStudentId(Long studentId) {
        Thesis thesis = thesisRepository.findByStudent_StudentId(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Sinh viên chưa đăng ký đề tài"));
        
        return mapToResponse(thesis);
    }
    
    public List<ThesisResponse> getThesesByLecturerId(Long lecturerId) {
        List<Thesis> theses = thesisRepository.findByLecturerIdWithDetails(lecturerId);
        return theses.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<ThesisResponse> getAllTheses() {
        List<Thesis> theses = thesisRepository.findAllWithDetails();
        return theses.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    @Transactional
    public void deleteThesis(Long thesisId) {
        Thesis thesis = thesisRepository.findById(thesisId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đề tài"));
        
        thesisRepository.delete(thesis);
    }
    
    private ThesisResponse mapToResponse(Thesis thesis) {
        return ThesisResponse.builder()
                .thesisId(thesis.getThesisId())
                .thesisTitle(thesis.getThesisTitle())
                .thesisContent(thesis.getThesisContent())
                .technologyUsed(thesis.getTechnologyUsed())
                .semester(thesis.getSemester())
                .status(thesis.getStatus())
                .score(thesis.getScore())
                .studentId(thesis.getStudent().getStudentId())
                .studentName(thesis.getStudent().getUser().getFullName())
                .studentCode(thesis.getStudent().getStudentCode())
                .studentEmail(thesis.getStudent().getUser().getEmail())
                .lecturerId(thesis.getLecturer().getLecturerId())
                .lecturerName(thesis.getLecturer().getUser().getFullName())
                .lecturerEmail(thesis.getLecturer().getUser().getEmail())
                .submittedAt(thesis.getSubmittedAt())
                .approvedAt(thesis.getApprovedAt())
                .createdAt(thesis.getCreatedAt())
                .build();
    }
}
